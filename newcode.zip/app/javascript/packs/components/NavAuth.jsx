import React from "react";
import {Link} from "react-router-dom";
export default class NavAuth extends React.Component{

    render(){
        return
            <div className="navigation">
                <Link to="/auth"  className="btn btn-primary mr-2">Sign Up</Link>
                <Link to="/auth" className="btn btn-primary mr-2">Log In</Link>
            </div>
    }
}
