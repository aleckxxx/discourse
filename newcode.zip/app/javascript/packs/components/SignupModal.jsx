import { Modal, Button } from "react-bootstrap";
import React from "react";
export default class SignupModal extends React.Component{
    state = {
        isOpen: false
    };
    render(){
        
    }
}