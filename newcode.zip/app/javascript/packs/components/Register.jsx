import React from "react";
import { authenticationService } from "../services/authentication.service";
import { Formik, Field, Form, ErrorMessage } from 'formik';
import * as Yup from 'yup';
import { Navigate } from "react-router-dom";

export default class Register extends React.Component{
    constructor(props){
      super(props);
      this.state = {
        canNavigate: false
      }
    }
    render(){
        return (
        {this.state.canNavigate && <Navigate to="/" />}
        <div className="form-auth shadow rounded">
            <h1 className="h3 mb-3 fw-normal">Please sign in</h1>
            <Formik
                   initialValues={{
                       username: '',
                       password: ''
                   }}
                   validationSchema={Yup.object().shape({
                       username: Yup.string().required('Username is required'),
                       password: Yup.string().required('Password is required')
                   })}
                   onSubmit={({ username, password }, { setStatus, setSubmitting }) => {
                       setStatus();
                       authenticationService.login(username, password)
                           .then(
                               user => {
                                 this.setSate({canNavigate: true});
                               },
                               error => {
                                  console.log(error);
                                   setSubmitting(false);
                                   setStatus(error);
                               }
                           );
                   }}
                   render={({ errors, status, touched, isSubmitting }) => (
                       <Form>
                           <div className="form-group">
                               <label htmlFor="username">Username</label>
                               <Field name="username" type="text" className={'form-control' + (errors.username && touched.username ? ' is-invalid' : '')} />
                               <ErrorMessage name="username" component="div" className="invalid-feedback" />
                           </div>
                           <div className="form-group">
                               <label htmlFor="password">Password</label>
                               <Field name="password" type="password" className={'form-control' + (errors.password && touched.password ? ' is-invalid' : '')} />
                               <ErrorMessage name="password" component="div" className="invalid-feedback" />
                           </div>
                           <div className="form-group">
                               <button type="submit" className="btn btn-primary" disabled={isSubmitting}>{isSubmitting? <div className="spinner-border text-light"></div>:"Sign In"}}</button>
                           </div>
                           {status &&
                               <div className={'alert alert-danger'}>{status}</div>
                           }
                       </Form>
                   )}
               />

        </div>)
    }
}
